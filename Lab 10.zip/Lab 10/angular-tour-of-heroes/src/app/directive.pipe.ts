import { Pipe, PipeTransform } from '@angular/core';
import { Directive, HostListener, ElementRef } from '@angular/core';
import { fromEventPattern } from 'rxjs';

@Pipe({
  name: 'directive'
})
export class DirectivePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return null;
  }

}
