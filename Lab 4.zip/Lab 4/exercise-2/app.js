const say = require('say')


say.speak("Hello", 'alex', 0.2)

let sorryDave = function(){
    say.speak("Im sorry Dave", 'Dave', 1)
}

//say.stop()
//say.speak(fs);
let delayed = function(a){
    setTimeout(a, 2000);
    return a;
}

delayed(sorryDave);





