var upperCase = require('upper-case')

console.log(upperCase('string'));
