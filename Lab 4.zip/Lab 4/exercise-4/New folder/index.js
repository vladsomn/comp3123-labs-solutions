var booksModule = require('./books');

module.exports = {
    booksModule : booksModule
}