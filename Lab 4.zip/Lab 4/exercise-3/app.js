var should = require('should');
var calc = require('./calculator');

calc.addTwoNumbers("a", "b");
calc.subtractTwoNumbers("a", "b");

describe('Calculator', function (){

    describe('when used synchronously', function(){

        it('should add two numbers correctly', function ()
        {
            calc.addTwoNumbers(2, 2).should.equal(4);
            

        });
        it('should add two numbers incorrectly', function ()
        {
            
            calc.addTwoNumbers(2, 2).should.not.equal(5);

        });

        it('should subtract two numbers correctly', function ()
        {
            calc.subtractTwoNumbers(8, 2).should.equal(6);
            

        });
        it('should subtract two numbers incorrectly', function ()
        {
            
            calc.subtractTwoNumbers(9, 2).should.not.equal(8);

        });
    })
});

