


exports.addTwoNumbers = function(a, b){
    return a+b;
   
}

exports.subtractTwoNumbers = function(a, b){
    return a-b;
   
}


