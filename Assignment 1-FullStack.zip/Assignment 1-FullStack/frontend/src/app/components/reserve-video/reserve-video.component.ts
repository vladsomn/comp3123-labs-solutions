import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../video.service';
import { Router,  ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { Video } from '../../video.model';
import { CustomerService } from '../../customer.service';
//import { Customer } from '../../customer.model';

import { Customer} from '../../../../../backend/models/customer';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { MatSnackBar } from '@angular/material';

import { fromEventPattern } from 'rxjs';
import { Input } from '@angular/core';



@Component({
  selector: 'reserve-video',
  templateUrl: './reserve-video.component.html',
  styleUrls: ['./reserve-video.component.css']
})
export class ReserveVideoComponent implements OnInit {

  id: String;
  video: any = {};
  customers: Customer[];
  firstname: string;
  lastname: string;
  updateForm: FormGroup;
  controlType = 'dropdown';
  //customers: {key: string, value: string}[] = [];


  

  constructor(private videoService: VideoService, private customerService: CustomerService, private route: ActivatedRoute, private snackBar: MatSnackBar, private fb: FormBuilder) { 
    this.createForm();
    //super(this.customers);
    //this.customers = this.customers['customers'] || [];
  }
  @Input() editable: boolean = false;
  
  createForm() {
    this.updateForm = this.fb.group({
      title: '',
      runtime: '',
      genre: '', 
      rating: '',
      director: '',
      status: '',
      customers: ''
    });
  }

  fetchCustomers() {
    this.customerService
    .getCustomers()
    .subscribe((data: Customer[]) => {
      this.customers = data;
      console.log('Data requested ... ');
      console.log(this.customers);
    });
  }

  ngOnInit() {
    this.fetchCustomers();
    
    this.route.params.subscribe(params => {
      this.id = params.id;
      
      this.videoService.getVideoById(this.id).subscribe(res => {
        this.video = res;
        
        this.updateForm.get('title').setValue(this.video.title);
        this.updateForm.get('runtime').setValue(this.video.runtime);
        this.updateForm.get('genre').setValue(this.video.genre);
        this.updateForm.get('rating').setValue(this.video.rating);
        this.updateForm.get('director').setValue(this.video.director);
        this.updateForm.get('customers').setValue(this.firstname);
        //this.updateForm.get('customers').setValue(this.customers.lastname);
        this.customerService.getCustomerByName(this.firstname, this.lastname);
      })
      //this.customerService.getCustomerByName(this.firstname, this.lastname).subscribe(res => {
        //this.customers = res;
      
      
    });
    
  
    



    }
  }

