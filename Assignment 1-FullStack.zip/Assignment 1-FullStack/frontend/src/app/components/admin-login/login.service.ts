import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { User } from '../../../../../backend/models/user';
import { User } from '../../../app/user.model';



@Injectable({
  providedIn: 'root'
})
export class LoginService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  getUserByUser(user) {
    return this.http.get(`${this.uri}/users/${user}`);
  }
  getUsers() {
    return this.http.get(`${this.uri}/users`);
  }

  findByUsername(username) {
    return this.http.get(`${this.uri}/users/${username}`);
  }
  findByPassword(password){
      return this.http.get(`${this.uri}/users/${password}`);
  }


}