import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListVideoAdminComponent } from './list-video-admin.component';

describe('ListVideoAdminComponent', () => {
  let component: ListVideoAdminComponent;
  let fixture: ComponentFixture<ListVideoAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListVideoAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListVideoAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
