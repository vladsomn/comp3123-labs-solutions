import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../video.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { MatSnackBar } from '@angular/material';
import { Video } from '../../video.model';



@Component({
  selector: 'app-update-video',
  templateUrl: './update-video.component.html',
  styleUrls: ['./update-video.component.css']
})
export class UpdateVideoComponent implements OnInit {

  id: String;
  video: any = {};
  updateForm: FormGroup;

  constructor(private videoService: VideoService, private route: ActivatedRoute, private snackBar: MatSnackBar, private fb: FormBuilder, private router: Router) { 
    this.createForm();
  }
  createForm() {
    this.updateForm = this.fb.group({
      title: ['', Validators.required ],
      runtime: '',
      genre: ['', Validators.required ],
      rating: '',
      director: '',
      status: ['', Validators.required ]
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params.id;
      this.videoService.getVideoById(this.id).subscribe(res => {
        this.video = res;
        this.updateForm.get('title').setValue(this.video.title);
        this.updateForm.get('runtime').setValue(this.video.runtime);
        this.updateForm.get('genre').setValue(this.video.genre);
        this.updateForm.get('rating').setValue(this.video.rating);
        this.updateForm.get('director').setValue(this.video.director);
        this.updateForm.get('status').setValue(this.video.status);
      });
    });
  }
  
  
  updateVideo(title, runtime, genre, rating, director, status) {
    this.videoService.updateVideo(this.id, title, runtime, genre, rating, director, status).subscribe(() => {
      this.snackBar.open('Video updated successfully', 'OK', {
        duration: 3000,
      }),
      this.router.navigate(['/list-video-admin'])
    });
   
  }
}
