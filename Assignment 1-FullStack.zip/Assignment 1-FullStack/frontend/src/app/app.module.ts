import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ListVideoComponent } from './components/list-video/list-video.component';
import { ListVideoAdminComponent } from './components/list-video-admin/list-video-admin.component';
import { AddVideoComponent } from './components/add-video/add-video.component';
import { UpdateVideoComponent } from './components/update-video/update-video.component';
import { ReserveVideoComponent } from './components/reserve-video/reserve-video.component';
import { CustomMaterialModule } from './core/material.module';
import { AdminLoginComponent } from './components/admin-login/admin-login.component'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginService } from '../app/components/admin-login/login.service';
import { MatToolbarModule, MatAutocomplete, MatFormFieldModule, MatInputModule, MatOptionModule, MatSelectModule, MatIconModule, MatButtonModule, MatCardModule, MatTableModule, MatDividerModule, MatSnackBarModule } from '@angular/material';

import { VideoService } from './video.service';
import { CustomersComponent } from './components/customers/customers.component';
import { CustomerService } from './customer.service';

import { FormsModule } from '@angular/forms';

//import { AppRoutingModule } from './app-routing.module';
import { AppRoutingModule } from './core/app.routing.module';
import { GrdFilterPipe } from './grd-filter.pipe';
import { AddCustomerComponent } from '../app/components/add-customer/add-customer.component';
import { UpdateCustomerComponent } from '../../../frontend/src/app/components/update-customer/update-customer.component';


const routes: Routes = [
  { path: 'admin-login', component: AdminLoginComponent},
  { path: 'add-customer', component: AddCustomerComponent},
  { path: 'customers', component:CustomersComponent},
  { path: 'list-video', component: ListVideoComponent },
  { path: 'list-video-admin', component: ListVideoAdminComponent },
  { path: 'add-video', component: AddVideoComponent },
  { path: 'update-video/:id', component: UpdateVideoComponent },
  { path: 'reserve-video/:id', component: ReserveVideoComponent },
  { path: 'update-customer/:id', component: UpdateCustomerComponent},
  { path: '', redirectTo: 'list-video', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    ListVideoComponent,
    ListVideoAdminComponent,
    AddVideoComponent,
    UpdateVideoComponent,
    ReserveVideoComponent,
    AdminLoginComponent,
    CustomersComponent,
    GrdFilterPipe,
    AddCustomerComponent,
    UpdateCustomerComponent
 
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatTableModule,
    MatDividerModule,
    MatSnackBarModule,
    AppRoutingModule,
    FormsModule,
    CustomMaterialModule,
    //MatAutocomplete

  ],
  providers: [VideoService, CustomerService, LoginService],
  bootstrap: [AppComponent, CustomersComponent, ListVideoAdminComponent, ListVideoComponent, UpdateVideoComponent, ReserveVideoComponent, AddVideoComponent, UpdateVideoComponent]
})
export class AppModule { }
