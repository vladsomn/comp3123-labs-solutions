export interface Login {
    id: String;
    username: String;
    password: String;
   
}
    