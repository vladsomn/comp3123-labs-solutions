import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class VideoService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  getVideos() {
    return this.http.get(`${this.uri}/videos`);
  }

  getVideoById(id) {
    return this.http.get(`${this.uri}/videos/${id}`);
  }
  getVideoByTitle(title) {
    return this.http.get(`${this.uri}/videos/${title}`);
  }

  addVideo(title, runtime, genre, rating, director, status) {
    const video = {
      title: title,
      runtime: runtime,
      genre: genre,
      rating: rating,
      director: director,
      status: status

      
    };
    return this.http.post(`${this.uri}/videos/add`, video);
  }
  updateVideo(id, title, runtime, genre, rating, director, status) {
    const video = {
      title: title,
      runtime: runtime,
      genre: genre,
      rating: rating,
      director: director,
      status: status
    };
    return this.http.post(`${this.uri}/videos/update/${id}`, video);
  }

  deleteVideo(id) {
    return this.http.get(`${this.uri}/videos/delete/${id}`);
  }

  updateCustomerReserve(firstname, lastname) {
    const customer = {
      firstname: firstname,
      lastname: lastname,
    

      
    };
    
  }

}
