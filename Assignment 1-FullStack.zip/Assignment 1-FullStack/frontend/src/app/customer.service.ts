import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  getCustomers() {
    return this.http.get(`${this.uri}/customers`);
  }

  getCustomerById(id) {
    return this.http.get(`${this.uri}/customers/${id}`);
  }
  
  getCustomerByName(firstname, lastname) {
    return this.http.get(`${this.uri}/customers/${firstname}`), this.http.get(`${this.uri}/customers/${lastname}`);
  }

  addCustomer(firstname, lastname, address, city, phone, status) {
    const customer = {
      firstname: firstname,
      lastname: lastname,
      address: address,
      city: city,
      phone: phone,
      status: status

      
    };
    return this.http.post(`${this.uri}/customers/add`, customer);
  }
  updateCustomer(id, firstname, lastname, address, city, phone, status) {
    const customer = {
      firstname: firstname,
      lastname: lastname,
      address: address,
      city: city,
      phone: phone,
      status: status

      
    };
    return this.http.post(`${this.uri}/customers/update/${id}`, customer);
  }

  updateCustomerById(id){
    return this.http.get(`${this.uri}/update-customer/${id}`);
  }
  
  deleteCustomer(id) {
    return this.http.get(`${this.uri}/customers/delete/${id}`);
  }

}
