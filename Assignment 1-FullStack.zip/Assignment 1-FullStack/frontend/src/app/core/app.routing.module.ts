import {NgModule}  from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListVideoAdminComponent  } from '../components/list-video-admin/list-video-admin.component';
import {AdminLoginComponent} from '../components/admin-login/admin-login.component';
import { ListVideoComponent } from '../components/list-video/list-video.component';
const routes: Routes = [
  { path: 'list-video-admin', component: ListVideoAdminComponent  },
  { path: 'admin-login', component: AdminLoginComponent },
  {path : '', component : ListVideoComponent}
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }