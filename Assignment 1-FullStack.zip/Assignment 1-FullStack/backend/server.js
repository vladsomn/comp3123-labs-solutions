
// npm start

import express from 'express';

import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import User from './models/user';
import Video from './models/video';
import Customer from './models/customer';
const app = express();
const router = express.Router();

//const router2 = express.Router();
app.use(cors());
app.use(bodyParser.json());
mongoose.connect('mongodb://admin:admin666@ds015928.mlab.com:15928/videos_db');
const connection = mongoose.connection;
connection.once('open', ()=> {
  console.log('MongoDB database connection established succesfully');
})
//app.get('/', (req, res) => res.send('Hello World!'));

//User

router.route('/users/all').get((req,res) =>{
    User.find((err, user) =>{
        if(err)
            console.log(err);
        else
            res.json(user);

    });
});

router.route('/users/:user').get((req,res)=>{
    User.findById(req.params.user,(err,user)=>{
        if(err)
            console.log(err);
        else
            res.json(user);
    });
});
router.route('/users/add').post((req,res)=>{
    let user = new User({
        username: "admin",
        password: "admin626"
    });
    user.save()
        .then(user => {
            res.status(200).json({'user': 'Added successfully'});
        })
        .catch(err =>{
            res.status(400).send('Failed to create a new record');
        });
});
/*
router.route('/users').get((req, res) => {
    User.find((err, users) => {
        if (err)
            console.log(err);
        else
            res.json(users);
            
    });
  });
  router.route('/users/:id').get((req, res) => {
    User.findById(req.params.id, (err, user) => {
        if (err)
            console.log(err);
        else
            res.json(user);
    });
  });
  router.route('/users/:username').get((req, res) => {
    User.findOne(req.params.username, (err, user) => {
        if (err)
            console.log(err);
        else
            res.json(user);
    });
});
router.route('/users/:password').get((req, res) => {
    User.findOne(req.params.password, (err, user) => {
        if (err)
            console.log(err);
        else
            res.json(user);
    });
});
*/
//Videos

router.route('/videos').get((req, res) => {
  Video.find((err, videos) => {
      if (err)
          console.log(err);
      else
          res.json(videos);
  });
});

router.route('/videos/:id').get((req, res) => {
  Video.findById(req.params.id, (err, video) => {
      if (err)
          console.log(err);
      else
          res.json(video);
  });
});

router.route('/videos/:title').get((req, res) => {
    Video.findByTitle(req.params.title, (err, video) => {
        if (err)
            console.log(err);
        else
            res.json(video);
    });
});

router.route('/videos/add').post((req, res) => {
  let video = new Video(req.body);
  video.save()
      .then(video => {
          res.status(200).json({'video': 'Added successfully'});
      })
      .catch(err => {
          res.status(400).send('Failed to create new record');
      });
});

router.route('/videos/update/:id').post((req, res) => {
  Video.findById(req.params.id, (err, video) => {
      if (!video)
          return next(new Error('Could not load document'));
      else {
          video.title = req.body.title;
          video.runtime = req.body.runtime;
          video.genre = req.body.genre;
          video.rating = req.body.rating;
          video.director = req.body.director;
          video.status = req.body.status;

          video.save().then(video => {
              res.json('Update done');
          }).catch(err => {
              res.status(400).send('Update failed');
          });
      }
  });
});

router.route('/videos/delete/:id').get((req, res) => {
  Video.findByIdAndRemove({_id: req.params.id}, (err, video) => {
      if (err)
          res.json(err);
      else
          res.json('Removed successfully');
  })
})


//Customers

router.route('/customers').get((req, res) => {
    Customer.find((err, customers) => {
        if (err)
            console.log(err);
        else
            res.json(customers);
    });
  });
  
  router.route('/customers/:id').get((req, res) => {
    Customer.findById(req.params.id, (err, customer) => {
        if (err)
            console.log(err);
        else
            res.json(customer);
    });
  });
  
  router.route('/customers/add').post((req, res) => {
    let customer = new Customer(req.body);
    customer.save()
        .then(customer => {
            res.status(200).json({'customer': 'Added successfully'});
        })
        .catch(err => {
            res.status(400).send('Failed to create new record');
        });
  });
  
  router.route('/customers/update/:id').post((req, res) => {
    Customer.findById(req.params.id, (err, customer) => {
        if (!customer)
            return next(new Error('Could not load document'));
        else {
            customer.firstname = req.body.firstname;
            customer.lastname = req.body.lastname;
            customer.address = req.body.address;
            customer.city = req.body.city;
            customer.phone = req.body.director;
            customer.status = req.body.status;
  
            customer.save().then(customer => {
                res.json('Update done');
            }).catch(err => {
                res.status(400).send('Update failed');
            });
        }
    });
  });
  
  router.route('/customers/delete/:id').get((req, res) => {
    Customer.findByIdAndRemove({_id: req.params.id}, (err, customer) => {
        if (err)
            res.json(err);
        else
            res.json('Removed successfully');
    })
  })






app.use('/', router);
app.listen(4000, () => console.log(`Express server running on port 4000`));
