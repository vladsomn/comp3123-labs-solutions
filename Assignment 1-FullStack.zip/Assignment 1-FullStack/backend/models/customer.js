import mongoose from 'mongoose';

const Schema = mongoose.Schema;

let Customer = new Schema({

    
    firstname: {
        type: String
    },
    lastname: {
        type: String 
    },
    address: {
        type: String
    },
    city: {
        type: String
    },
    phone: {
        type: String
    },
    status: {
        type: String,
        default: 'Active'
    }
});

export default mongoose.model('Customer', Customer);