import mongoose from 'mongoose';

const Schema = mongoose.Schema;

let Video = new Schema({
    title: {
        type: String
    },
    runtime: {
        type: String 
    },
    genre: {
        type: String
    },
    rating: {
        type: String
    },
    director: {
        type: String
    },
    status: {
        type: String,
        default: 'Available'
    }
});

export default mongoose.model('Video', Video);