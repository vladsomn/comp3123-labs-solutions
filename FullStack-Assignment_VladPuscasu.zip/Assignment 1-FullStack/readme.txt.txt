username: admin
password: admin626
frontend: host: 4200 - 'ng serve'
backend: host: 4000 - 'npm start'
missing node_module in frontend and backend folders


Vlad Puscasu
101102569