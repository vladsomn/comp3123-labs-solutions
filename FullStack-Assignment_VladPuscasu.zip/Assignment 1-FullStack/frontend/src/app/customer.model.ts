export interface Customer {
    id: String;
    firstname: String;
    lastname: String;
    address: String;
    city: String;
    phone: String;
    status: String;
       
    
}
