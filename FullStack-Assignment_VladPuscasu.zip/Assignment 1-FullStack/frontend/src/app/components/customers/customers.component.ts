import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../customer.service';
import { Customer } from '../../customer.model';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';

import { fromEventPattern } from 'rxjs';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  customers: any[];
  public searchText: string;

  displayedColumns = ['firstname', 'lastname', 'address', 'city', 'phone', 'status'];
  constructor(private customerService: CustomerService, private router: Router) { }

  ngOnInit() {
    this.fetchCustomers();
    this.customers;
    this.searchText;
  }

  fetchCustomers() {
    this.customerService
    .getCustomers()
    .subscribe((data: Customer[]) => {
      this.customers = data;
      console.log('Data requested ... ');
      console.log(this.customers);
    });
  }
  getCustomerByName(firstname, lastname) {
    this.customerService.getCustomerByName(firstname, lastname).subscribe(() =>{
      this.fetchCustomers();
    });
   }
  updateCustomer(id) {
    this.router.navigate([`/update-customer/${id}`]);
  }

  deleteCustomer(id) {
    this.customerService.deleteCustomer(id).subscribe(() => {
      this.fetchCustomers();
    });
  }

}