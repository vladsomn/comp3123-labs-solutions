
import { ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../video.service'
import { MatTableDataSource } from '@angular/material';
import { Video } from '../../video.model';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-add-video',
  templateUrl: './add-video.component.html',
  styleUrls: ['./add-video.component.css']
})
export class AddVideoComponent implements OnInit {

  createForm: FormGroup;

  constructor(private videoService: VideoService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar) {
    this.createForm = this.fb.group({
      title: ['', Validators.required],
      runtime: '',
      genre: ['', Validators.required],
      rating: '',
      director: '',
      status: ['', Validators.required]
    });
  }

  addVideo(title, runtime, genre, rating, director, status) {
    this.videoService.addVideo(title, runtime, genre, rating, director, status).subscribe(() => {
     
      
      this.snackBar.open('Video added', 'OK', {
        duration: 3000,
      }),
      this.router.navigate(['/list-video-admin'])
    });
  }

  ngOnInit() {
  }

}
