import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../video.service';
import { Video } from '../../video.model';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { MatAutocompleteModule, MatInputModule } from '@angular/material';

@Component({
  selector: 'app-list-video',
  templateUrl: './list-video.component.html',
  styleUrls: ['./list-video.component.css']
})
export class ListVideoComponent implements OnInit {

  videos: any [];
  public searchText : string;
  displayedColumns = ['title', 'runtime', 'genre', 'rating', 'director', 'status', 'reserve'];
  constructor(private videoService: VideoService, private router: Router) { }

  ngOnInit() {
    this.fetchVideos();
    this.videos;
    this.searchText;
    
  }
  reserveVideo(id) {
    this.router.navigate([`/reserve-video/${id}`]);
  }
  getVideoByTitle(title) {
    this.videoService.getVideoByTitle(title).subscribe(() =>{
      this.fetchVideos();
    });
   }
  fetchVideos() {
    this.videoService
    .getVideos()
    .subscribe((data: Video[]) => {
      this.videos = data;
      console.log('Data requested ... ');
      console.log(this.videos);
    });
  }
  

}
