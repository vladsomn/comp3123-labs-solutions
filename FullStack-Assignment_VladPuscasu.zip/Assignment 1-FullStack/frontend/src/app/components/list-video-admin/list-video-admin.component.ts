import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../video.service';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { Video } from '../../video.model';
import { FormControl } from '@angular/forms';


import { fromEventPattern } from 'rxjs';


@Component({
  selector: 'app-list-video-admin',
  templateUrl: './list-video-admin.component.html',
  styleUrls: ['./list-video-admin.component.css']
})
export class ListVideoAdminComponent implements OnInit {

  videos: any [];  
  //displayedColumns = ['title', 'runtime', 'genre', 'rating', 'director', 'status', 'actions'];
  //videoTitle = new FormControl();
  public searchText : string;
  //public videos: any;

  
  constructor(private videoService: VideoService, private router: Router) { }

  ngOnInit() {
    this.fetchVideos();
    this.videos;
    //this.getVideoByTitle;
    this.searchText;
    console.log(this.searchText);
    console.log(this.videos);

  }
  getVideoByTitle(title) {
   this.videoService.getVideoByTitle(title).subscribe(() =>{
     this.fetchVideos();
   });
  }

  fetchVideos() {
    this.videoService
    .getVideos()
    .subscribe((data: Video[]) => {
      this.videos = data;
      console.log('Data requested ... ');
      console.log(this.videos);
    });
  }

  updateVideo(id) {
    this.router.navigate([`/update-video/${id}`]);
  }

  deleteVideo(id) {
    this.videoService.deleteVideo(id).subscribe(() => {
      this.fetchVideos();
    });
  }
}
