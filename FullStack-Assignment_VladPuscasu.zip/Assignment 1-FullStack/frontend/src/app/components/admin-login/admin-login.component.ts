import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material';
import { MatMenu } from '@angular/material';
import { LoginService } from './login.service';
import { User} from '../../../app/user.model';
//import { User } from '../../../../../backend/models/User';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
//import { ListVideoAdmin } from '../list-video-admin/list-video-admin.component';
import { MatSnackBar} from '@angular/material';


@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  users :User[];
  userDb: String;
  passwordDb: String;
  user: String;
  password: String;
  loginForm : FormGroup;
  

  constructor(private loginService: LoginService, private fb: FormBuilder, private router:Router,private snackbar:MatSnackBar) { 
      this.loginForm = this.fb.group({
      user: ['',Validators.required],
      password: ['',Validators.required],
    
    });
  }
  Login(){
    this.user = this.loginForm.controls['user'].value;
    this.password = this.loginForm.controls['password'].value;
    //check db for user and return the object associated with that user
    this.loginService.getUserByUser("5c0d94adfb6fc04dd6e8cae8").subscribe((data: JSON)=>{
      this.userDb = data["username"];
      this.passwordDb = data["password"];
    if(this.userDb === this.user && this.passwordDb === this.password){
      sessionStorage.setItem('valid', "true");
      this.router.navigate(['list-video-admin'])
    }
    else{
      this.snackbar.open('Incorrect Username or Password','OK',{
        duration: 3000
      });
      this.router.navigate([`admin-login`]);
    } 
  });  
  }

  ngOnInit() {
    
  }

}
