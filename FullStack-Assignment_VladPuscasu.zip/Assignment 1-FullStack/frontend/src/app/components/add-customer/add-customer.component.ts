
import { ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../../app/customer.service'
import { MatTableDataSource } from '@angular/material';
import { Customer } from '../../../app/customer.model';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  createForm: FormGroup;

  constructor(private customerService: CustomerService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar) {
    this.createForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: '',
      address: ['', Validators.required],
      city: '',
      phone: '',
      status: ['', Validators.required]
    });
  }

  addCustomer(firstname, lastname, address, city, phone, status) {
    this.customerService.addCustomer(firstname, lastname, address, city, phone, status).subscribe(() => {
     
      
      this.snackBar.open('Customer added', 'OK', {
        duration: 3000,
      }),
      this.router.navigate(['/add-customer'])
    });
  }

  ngOnInit() {
  }

}
