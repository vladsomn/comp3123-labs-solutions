import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { MatSnackBar } from '@angular/material';
import { Customer } from '../../customer.model';



@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  id: String;
  customer: any = {};
  updateForm: FormGroup;

  constructor(private customerService: CustomerService, private route: ActivatedRoute, private snackBar: MatSnackBar, private fb: FormBuilder, private router: Router) { 
    this.createForm();
  }
  createForm() {
    this.updateForm = this.fb.group({
      firstname: ['', Validators.required ],
      lastname: ['', Validators.required ],
      address: ['', Validators.required ],
      city: '',
      phone: '',
      status: ['', Validators.required ]
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params.id;
      this.customerService.getCustomerById(this.id).subscribe(res => {
        this.customer = res;
        this.updateForm.get('firstname').setValue(this.customer.firstname);
        this.updateForm.get('lastname').setValue(this.customer.lastname);
        this.updateForm.get('address').setValue(this.customer.address);
        this.updateForm.get('city').setValue(this.customer.city);
        this.updateForm.get('phone').setValue(this.customer.phone);
        this.updateForm.get('status').setValue(this.customer.status);
      });
    });
  }
  
  
  updateCustomer(firstname, lastname, address, city, phone, status) {
    this.customerService.updateCustomer(this.id, firstname, lastname, address, city, phone, status).subscribe(() => {
      this.snackBar.open('Customer updated successfully', 'OK', {
        duration: 3000,
      }),
      this.router.navigate(['/customers'])
    });
   
  }
}
