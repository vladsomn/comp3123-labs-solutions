var express = require('express');
var app = express();
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({ name: String, status: String});

var User = mongoose.model('User', userSchema);

mongoose.connect('mongodb://admin:sinaia69@ds127843.mlab.com:27843/locallibrary');

var port = process.env.PORT || 3000;
app.listen(port);

var john = User({ name: 'John', status: 'active'});
var jane = User({ name: 'Jane', status: 'active'});

john.save(function(err) {
    if (err) throw err;

    console.log('**** User saved! ****');
});

jane.save(function(err) {
    if (err) throw err;

    console.log('**** User saved *&&***');
});

