var express = require('express');
var app = express();
var requestTime = function (req, res, next) {
    req.requestTime = Date.now()
    next()
}

app.listen(3000);
app.use(requestTime)

app.get('/greet', function (req, res) {
    console.log('GET received: ' + req.requestTime);
    res.send('hello world!');
});  

// Post method

app.post('/greet', function (req, res) {
    console.log('Post received: ' + req.requestTime);
    res.send('POST hello world!')
});

app.delete('/greet', function (req, res) {
    console.log('DELETED ');
    res.send('DELETED')
});
