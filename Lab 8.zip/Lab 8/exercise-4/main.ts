import {Customer} from './customer'

let customer = new Customer("John", "Smith", 34);
customer.greeter();
customer.GetAge();
