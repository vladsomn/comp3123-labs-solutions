let greeter = (firstname, lastname) => {
    console.log(`Hello ${firstname} ${lastname}`);
};
greeter("John", "Smith");