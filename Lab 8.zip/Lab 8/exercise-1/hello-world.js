var greeter = function (firstname, lastname) {
    console.log("Hello " + firstname + " " + lastname);
};
greeter("John", "Smith");
