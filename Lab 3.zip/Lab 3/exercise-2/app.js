// require built-in file system
var ft = require('./writer');

// create readable stream to read in the file
ft.writeData();

