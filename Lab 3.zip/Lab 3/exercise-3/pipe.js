
var request = require('request');

var fs = require('fs');

request('http://www.google.com', function(error, res, body){
    console.log('error:', error); // Print the error if one occurred
    console.log('statusCode:', response && response.statusCode);     
    console.log('body: ', body);
})