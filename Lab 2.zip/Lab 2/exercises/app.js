//var ft = require('./sportsteam');
var comp = require("./comparerer");
var calc = require("./calculator");
var events = require('events');
var eventEmitter = new events.EventEmitter();

//Exercise 1
// set module property
//ft.teamname = 'Leafs';
//ft.teamname2 = 'Sens';

// call module method 
//ft.Cheer();
//ft.Boo();

//Exercise 2
var num1 = 5
var num2 = 10


var result = 
(comp.AreNumbersEqual(num1, num2))
 ? calc.Add(num1, num2) 
 : calc.Subtract(num1, num2);

console.log(result);

//Exercise 3

var fn = function()
{
    console.log('call me. ');
}

var alarm = function()
{
    console.log('Alarm has been triggered.');
}


// event listeners
eventEmitter
    .on('call', fn)
    .emit('call');

    // event emitters 
eventEmitter.on('xx', alarm)
eventEmitter.emit('xx');






 