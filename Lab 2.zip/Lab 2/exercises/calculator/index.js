exports.Add = function(num1, num2){
    console.log('numbers are equal');
    return num1 + num2;
}

exports.Subtract = function(num1, num2)
{
    console.log('numbers are not equal')
    return num1 - num2;
}